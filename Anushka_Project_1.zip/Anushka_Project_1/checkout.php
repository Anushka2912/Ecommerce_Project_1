<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Seek-A-Word</title>
        <link rel="stylesheet" href="styling.css">
    </head>
    <body>
    <div id="navigation">
        <div id="logopos">
            <img src="images/logo.png" alt="website logo">
        </div>

        <div id="navigationitems">
            <a href="home.php">Home</a>
            <a href="about.php">About</a>
            <a href="bookstore.php">Bookstore</a>
            <a href="orders.php">Orders</a>
        </div>
    </div>
    <div id="checkout">
        <div id="formbox">
            <form method="POST" action="checkout.php">
                <p>Firstname: <input type="text" name="fname" value="<?php if(isset($_POST['fname'])) echo $_POST['fname']; ?>"></p>
                <p>Lastname: <input type="text" name="lname" value="<?php if(isset($_POST['lname'])) echo $_POST['lname']; ?>"></p>
                <p>Email: <input type="text" name="email" value="<?php if(isset($_POST['email'])) echo $_POST['email']; ?>"></p>
                <p>Phone: <input type="text" name="phone" value="<?php if(isset($_POST['phone'])) echo $_POST['phone']; ?>"></p>
                <label>Payment Method:</label>
                <select name="payment">
                    <option value="">Select an option</option>
                    <option value="Credit/Debit Card">Credit/Debit Card</option>
                    <option value="Cash">Cash</option>
                    <option value="COD">Cash on Delivery</option>
                </select>
                <p><input type="submit" value="Place Order" name="submit"></p>
            </form> 
            <!--PHP Script start -->
            <?php
            
            session_start();

            $queries = array();
            parse_str($_SERVER['QUERY_STRING'], $queries);

            require('mysqli_connect.php');
            if(isset($queries['id'])){

                $id = $queries['id'];
                $q2 = "SELECT book_id, book_name, auth_name, pub_name, pub_year, book_price, stock 
                FROM author
                JOIN bookinventory
                ON author.auth_id=bookinventory.auth_id
                JOIN publisher
                ON bookinventory.pub_id=publisher.pub_id 
                WHERE book_id = $id ";
                $r2 = $connection->query($q2);
    
                if ($r2->num_rows > 0) {
                    while($row = $r2->fetch_assoc()) {
                        $_SESSION['id'] = $row['book_id'];
                        $_SESSION["book"] = $row['book_name'];
                        $_SESSION["author"] = $row['auth_name'];
                        $_SESSION["publisher"] = $row['pub_name'];
                        $_SESSION["pyear"] = $row['pub_year'];
                        $_SESSION["price"] = $row['book_price'];
                        $_SESSION["stock"] = $row['stock'];
                    }
                }
            }

            $err = array();
            
            if($_SERVER["REQUEST_METHOD"] == "POST") {
                    
                $firstname = $_POST['fname'];
                $lastname = $_POST['lname'];
                $paymentM = $_POST['payment'];
                $emailA = $_POST['email'];
                $phoneN = $_POST['phone'];
                $id= $_SESSION['id'];

                if(!empty($_POST['$firstname']) || strlen($firstname) == 0){
                    array_push($err, "Please enter your firstname.<br>");
                }else {
                    $firstname = filter_var($_POST['fname'], FILTER_SANITIZE_STRING);
                }

                if(!empty($_POST['$lastname']) || strlen($lastname) == 0){
                    array_push($err, "Please enter your lastname.<br>");
                }else {
                    $lastname = filter_var($_POST['lname'], FILTER_SANITIZE_STRING);
                }

                if(!empty($_POST['$paymentM']) || strlen($paymentM) == 0){
                    array_push($err, "Please select one payment method.<br>");
                }else {
                    $paymentM = filter_var($_POST['payment'], FILTER_SANITIZE_STRING);
                }
                
                if(!empty($_POST['$emailA']) || strlen($emailA) == 0){
                    array_push($err, "Please enter your email address.<br>");
                }else {
                    $emailA = filter_var($_POST['email'], FILTER_SANITIZE_STRING);
                }
                
                if(!empty($_POST['$phoneN']) || strlen($phoneN) == 0){
                    array_push($err, "Please enter your phone number.<br>");
                }else {
                    $phoneN = filter_var($_POST['phone'], FILTER_SANITIZE_STRING);
                }                   
                
                if(empty($err))
                {
                    $q3 = "INSERT INTO bookinventoryorder (firstName, lastName, payment, email, phone)
                            VALUES ('$firstname','$lastname','$paymentM ','$emailA','$phoneN')";
                    
                    $r3 = mysqli_query($connection, $q3);

                    $sql = "SELECT * FROM bookinventory WHERE book_id = $id";
                    $q4 = mysqli_query($connection,$sql) or die( mysqli_error($connection));
                    $r4 = mysqli_fetch_array($q4);
                    $stockval = $r4['stock'];

                    $stockupdated = $stockval - 1;

                    $newstock = mysqli_query($connection,"UPDATE bookinventory SET stock = '$stockupdated' WHERE book_id = $id");
                    
                    if($r3 || $newstock)
                    {
                        header("Location: success.php");
                    }
                    else
                    {
                        echo "Order not placed";
                    }
                } else {
                    foreach($err as $e) {
                        echo $e, '<br>';
                    }
                    
                } 
            }
            mysqli_close($connection);
            ?>
            <!--PHP Script ends-->
        </div>
    </div>

    <div id="footer">
        <div id="linkbox">
            <p>Helpful Links<p>
            <a href="about.php">About Us</a><br><br>
            <a href="bookstore.php">Bookstore</a>
        </div>

        <div id="contactbox">
            <p>Contact<p>
            <p>seekaword@gmail.com</p>
            <p>+1-2542634568</p>
            <div id="medialinks">
                <img src="images/fb.jpg" alt="fb" height="30px" width="40px">
                <img src="images/ig.jpg" alt="ig" height="30px" width="30px">
                <img src="images/tw.png" alt="tw" height="30px" width="30px">
            </div>
        </div>

        <div id="addressbox">
            <p>Address<p>
            <p>1229 Marlborough Ct</p>
            <p>Oakville,Ontario</p>
            <p>L6H 3B6 Canada</p>
        </div>
    </div>
    <div id="copyrightbox">
        <p>&#169; Copyright 2021 by Anushka Sharma</p> 
    </div>
    </body>
</html>
