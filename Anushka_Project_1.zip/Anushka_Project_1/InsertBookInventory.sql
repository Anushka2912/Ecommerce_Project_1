INSERT INTO category (cat_name)
VALUES ("fiction"),("novel"),("mystery"),("autobiography"),("romance");

INSERT INTO author(auth_name)
VALUES ("George Orwell"),("Margaret Atwood"),("Aldous Huxley"),("Charles Dickens"),("Stieg Larsson"),
("Agatha Christie"),("Priyanka Chopra"),("Michelle Obama"),("Jenny Han"),("John Green");

INSERT INTO publisher(pub_name)
VALUES ("Secker & Warburg"),("McClelland and Stewart"),("Chatto & Windus"),("Chapman & Hall"),("Norstedts Förlag"),
("Collins Crime Club"),("Penguin Random House"),("Crown Publishing Group"),("Simon & Schuster"),("Dutton Books");

INSERT INTO bookinventory(book_name, book_price, pub_year, stock, auth_id, pub_id, cat_id)
VALUES ("Nineteen Eighty-Four","11.87","1949","10","1","1","1"),
("The Handmaid's Tale","26.19","1985","13","2","2","1"),
("Brave New World","14.40","1932","7","3","3","2"),
("A Tale of Two Cities","17.01","1859","5","4","4","2"),
("The Girl with the Dragon Tattoo","22","2005","2","5","5","3"),
("Murder on the Orient Express","11.33","1934","7","6","6","3"),
("Unfinished","22.36","2021","23","7","7","4"),
("Becoming","31.99","2018","4","8","8","4"),
("To All The Boys I've Loved Before","9.99","2014","15","9","9","5"),
("The Fault in Our Stars","14.84","2012","30","10","10","5");