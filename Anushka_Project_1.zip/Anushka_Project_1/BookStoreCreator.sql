CREATE TABLE bookInventory(
	book_id INT AUTO_INCREMENT,
    book_name VARCHAR(255) NOT NULL,
    book_price DECIMAL(10,2) NOT NULL,
    pub_year INT NOT NULL,
    stock INT NOT NULL,
    auth_id INT NOT NULL,
    pub_id INT NOT NULL,
    cat_id INT NOT NULL,
    PRIMARY KEY(book_id),
    FOREIGN KEY(auth_id) REFERENCES author(auth_id),
    FOREIGN KEY(pub_id) REFERENCES publisher(pub_id),
    FOREIGN KEY(cat_id) REFERENCES category(cat_id)
);

CREATE TABLE author(
	auth_id INT AUTO_INCREMENT,
    auth_name VARCHAR(255) NOT NULL,
    PRIMARY KEY(auth_id)
);

CREATE TABLE publisher(
	pub_id INT AUTO_INCREMENT,
    pub_name VARCHAR(255) NOT NULL,
    PRIMARY KEY(pub_id)
);

CREATE TABLE category(
	cat_id INT AUTO_INCREMENT,
    cat_name VARCHAR(255) NOT NULL,
    PRIMARY KEY(cat_id)
);

CREATE TABLE bookinventoryorder(
	order_id INT AUTO_INCREMENT,
    firstName VARCHAR(255) NOT NULL,
    lastName VARCHAR(255) NOT NULL,
    payment VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone INT NOT NULL,
    PRIMARY KEY(order_id)
);