<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Seek-A-Word</title>
        <link rel="stylesheet" href="styling.css">
    </head>
    <body>
    <div id="navigation">
        <div id="logopos">
            <img src="images/logo.png" alt="website logo">
        </div>

        <div id="navigationitems">
            <a href="home.php">Home</a>
            <a href="about.php">About</a>
            <a href="bookstore.php">Bookstore</a>
            <a href="orders.php">Orders</a>
        </div>
    </div>

    <div id="displaydata">
        <p>Success</p>
    </div>
    
    <div id="footer">
        <div id="linkbox">
            <p>Helpful Links<p>
            <a href="about.php">About Us</a><br><br>
            <a href="bookstore.php">Bookstore</a>
        </div>

        <div id="contactbox">
            <p>Contact<p>
            <p>seekaword@gmail.com</p>
            <p>+1-2542634568</p>
            <div id="medialinks">
                <img src="images/fb.jpg" alt="fb" height="30px" width="40px">
                <img src="images/ig.jpg" alt="ig" height="30px" width="30px">
                <img src="images/tw.png" alt="tw" height="30px" width="30px">
            </div>
        </div>

        <div id="addressbox">
            <p>Address<p>
            <p>1229 Marlborough Ct</p>
            <p>Oakville,Ontario</p>
            <p>L6H 3B6 Canada</p>
        </div>
    </div>
    <div id="copyrightbox">
        <p>&#169; Copyright 2021 by Anushka Sharma</p> 
    </div>
    </body>
</html>