<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Seek-A-Word</title>
        <link rel="stylesheet" href="styling.css">
    </head>
    <body>
    <div id="navigation">
        <div id="logopos">
            <img src="images/logo.png" alt="website logo">
        </div>

        <div id="navigationitems">
            <a href="home.php">Home</a>
            <a href="about.php">About</a>
            <a href="bookstore.php">Bookstore</a>
            <a href="orders.php">Orders</a>
        </div>
    </div>
    <div id="datadisplay">
        <?php
            require('mysqli_connect.php');

            $q1 = "SELECT book_id, book_name, auth_name, pub_name, pub_year, book_price, stock FROM author
            JOIN bookinventory
            ON author.auth_id=bookinventory.auth_id
            JOIN publisher
            ON bookinventory.pub_id=publisher.pub_id";
            
            $r1 = mysqli_query($connection, $q1);
            
            $num = mysqli_num_rows($r1);

            if($num>0) {
                while($row = mysqli_fetch_array($r1, MYSQLI_ASSOC)){
                ?>
                    <a href="checkout.php?id=<?php echo $row['book_id']; ?>">
                    <br>Name : <?php echo $row['book_name']; ?><br>
                    Author : <?php echo $row['auth_name']; ?><br>
                    Publisher : <?php echo $row['pub_name']; ?><br>
                    Published Year : <?php echo $row['pub_year']; ?><br>
                    Price : $<?php echo $row['book_price']; ?><br>
                    Stock : <?php echo $row['stock']; ?></a><br>
                        
                <?php
                } 
                mysqli_free_result($r1);
                
            }else {
                echo '<br>There are no books in the database.';
            }
            mysqli_close($connection);
        ?>
    </div>

    <div id="footer">
        <div id="linkbox">
            <p>Helpful Links<p>
            <a href="about.php">About Us</a><br><br>
            <a href="bookstore.php">Bookstore</a>
        </div>

        <div id="contactbox">
            <p>Contact<p>
            <p>seekaword@gmail.com</p>
            <p>+1-2542634568</p>
            <div id="medialinks">
                <img src="images/fb.jpg" alt="fb" height="30px" width="40px">
                <img src="images/ig.jpg" alt="ig" height="30px" width="30px">
                <img src="images/tw.png" alt="tw" height="30px" width="30px">
            </div>
        </div>

        <div id="addressbox">
            <p>Address<p>
            <p>1229 Marlborough Ct</p>
            <p>Oakville,Ontario</p>
            <p>L6H 3B6 Canada</p>
        </div>
    </div>
    <div id="copyrightbox">
        <p>&#169; Copyright 2021 by Anushka Sharma</p> 
    </div>
    </body>
</html>
